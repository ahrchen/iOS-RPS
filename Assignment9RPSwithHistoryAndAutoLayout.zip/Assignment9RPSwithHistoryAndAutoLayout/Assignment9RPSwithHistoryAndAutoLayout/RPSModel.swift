//
//  RPSModel.swift
//  Assignment8RPSwithHistory
//
//  Created by Raymond Chen on 3/26/18.
//  Copyright © 2018 Raymond Chen. All rights reserved.
//

import Foundation

internal var rpsGame = RPSGame()
