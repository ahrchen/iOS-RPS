//
//  ViewController.swift
//  Assignment6RockPaperScissors
//
//  Created by rchen14 on 3/9/18.
//  Copyright © 2018 rchen14. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var gameLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func RockButton(_ sender: Any) {
        rpsGame.userMove = RPSGame.RPSMove.rock
        resultLabel.text = rpsGame.gameResult()
        gameLabel.text = rpsGame.getGameTotal()
    }
    
    @IBAction func PaperButton(_ sender: Any) {
        rpsGame.userMove = RPSGame.RPSMove.paper
        resultLabel.text = rpsGame.gameResult()
        gameLabel.text = rpsGame.getGameTotal()
    }
    @IBAction func ScissorsButton(_ sender: Any) {
        rpsGame.userMove = RPSGame.RPSMove.scissors
        resultLabel.text = rpsGame.gameResult()
        gameLabel.text = rpsGame.getGameTotal()
    }
}

