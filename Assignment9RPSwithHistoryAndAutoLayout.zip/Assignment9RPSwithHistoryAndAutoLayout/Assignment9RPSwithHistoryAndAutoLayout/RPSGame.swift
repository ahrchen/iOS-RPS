//
//  RPSGame.swift
//  Assignment6RockPaperScissors
//
//  Created by rchen14 on 3/9/18.
//  Copyright © 2018 rchen14. All rights reserved.
//

import Foundation

class RPSGame: NSObject {

    //Create an enum to formalize the three possible moves
    enum RPSMove
    {
        case rock, paper, scissors
        
        //studied how to choose a random enumeration value
        //https://stackoverflow.com/questions/42299713/choose-random-value-from-enum/42299977

        static func randomCPUMove() ->RPSMove
        {
            let movesToGetRandomly = [RPSMove.rock, RPSMove.paper, RPSMove.scissors]
            let index = Int(arc4random_uniform(UInt32(movesToGetRandomly.count)))
            let move = movesToGetRandomly[index]
            return move
        }
    }
    
    //Properties
    var userMove: RPSMove?
    var cpuMove: RPSMove?
    var matches = [String]()
    var wins = 0
    var loss = 0
    var ties = 0
    
    func gameResult() -> String
    {
        cpuMove = RPSMove.randomCPUMove()
        var result = ""
        if userMove != nil && cpuMove != nil
        {
            switch userMove! {
            case .rock:
                switch cpuMove!
                {
                case .rock:
                    result = "👊 vs. 👊.  🎭You Tie!🎭"
                    ties += 1
                case .paper:
                    result = "👊 vs. 🖐.  💔You Lose!💔"
                    loss += 1
                case .scissors:
                    result = "👊 vs. ✌️.  🏆You Win!🏆"
                    wins += 1
                }
            case .paper:
                switch cpuMove!
                {
                case .rock:
                    result = "🖐 vs. 👊.  🏆You Win!🏆"
                    wins += 1
                case .paper:
                    result = "🖐 vs. 🖐.  🎭You Tie!🎭"
                    ties += 1
                case .scissors:
                    result = "🖐 vs. ✌️.  💔You Lose!💔"
                    loss += 1
                }
            case .scissors:
                switch cpuMove!
                {
                case .rock:
                    result = "✌️ vs. 👊.  💔You Lose!💔"
                    loss += 1
                case .paper:
                    result = "✌️ vs. 🖐.  🏆You Win!🏆"
                    wins += 1
                case .scissors:
                    result = "✌️ vs. ✌️.  🎭You Tie!🎭"
                    ties += 1
                }
            }
        }
        matches.append(result)
        return result
    }
    
    func displayAllResults()
    {
        for result in matches
        {
            print(result)
        }
    }
    
    func getGameTotal() -> String
    {
        let output = "Win:\(wins) Loss:\(loss) Ties:\(ties)"
        return output
    }
}



